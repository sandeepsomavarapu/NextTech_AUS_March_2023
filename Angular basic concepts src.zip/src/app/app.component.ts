import { Component } from '@angular/core';

@Component({
  selector: 'xyz',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
 name:string="NextTech"; 
}
