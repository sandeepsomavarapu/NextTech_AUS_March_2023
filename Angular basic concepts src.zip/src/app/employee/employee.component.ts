import { Component } from '@angular/core';

@Component({
  selector: 'emp',
  template: `
  <h1>welcome to angular components</h1>
  <h1>welcome to India</h1>
  `,
  styles:[`h1{color:blue;
  background-color:yellow;
  }

  `]
})
export class EmployeeComponent {

}
