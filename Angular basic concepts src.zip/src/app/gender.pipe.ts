import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'custom'
})
export class GenderPipe implements PipeTransform {

  transform(name: String, gender:String): String {
    if(gender.toLowerCase()==="male")
     return "MR "+name;
    else
      return "Miss "+name;
  }

}
