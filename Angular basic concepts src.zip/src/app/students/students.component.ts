import { Component } from '@angular/core';

@Component({
  selector: 'students',
  templateUrl: './students.component.html',
  styleUrls: ['./students.component.css']
})
export class StudentsComponent {
  student:any;
  constructor() {
    this.student = {
      FirstName : "Aman",
      LastName : "Kumar",
      Gender : "Male"
  };
}
}
