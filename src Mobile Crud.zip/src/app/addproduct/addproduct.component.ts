import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { Mobile, ProductService } from '../product.service';

@Component({
  selector: 'app-addproduct',
  templateUrl: './addproduct.component.html',
  styleUrls: ['./addproduct.component.css']
})
export class AddproductComponent {

  constructor(private service: ProductService,public router:Router) {
    
  }

  add(mobile:Mobile)
  {
    this.service.addMobile(mobile)
    alert("Mobile Added successfully")
    this.router.navigate(['list'])
  }
}
