import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { Mobile, ProductService } from '../product.service';

@Component({
  selector: 'app-listproduct',
  templateUrl: './listproduct.component.html',
  styleUrls: ['./listproduct.component.css']
})
export class ListproductComponent {
  mobiles:Mobile[];
  constructor(private service: ProductService,private router:Router) {
    this.listProducts();
  }
  listProducts() {
   this.mobiles=this.service.getMobiles();
   console.log(this.mobiles);
  }
delete(mid:number)
{
  this.service.deleteMobile(mid);
  this.mobiles=this.service.getMobiles();
}
update()
{
  this.router.navigate(['/update']);
}

}
