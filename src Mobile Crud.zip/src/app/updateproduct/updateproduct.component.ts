import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { Mobile, ProductService } from '../product.service';

@Component({
  selector: 'app-updateproduct',
  templateUrl: './updateproduct.component.html',
  styleUrls: ['./updateproduct.component.css']
})
export class UpdateproductComponent {
  
  constructor(private service: ProductService,public router:Router) {
    
  }
  update(mobile:Mobile)
  {
    this.service.updateMobile(mobile);
    alert("Mobile Updated successfully");
    this.router.navigate(['list']);
  }
}
