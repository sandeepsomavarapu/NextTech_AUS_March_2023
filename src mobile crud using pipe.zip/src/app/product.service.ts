import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
@Injectable({
  providedIn: 'root'
})
export class ProductService {
  
  
 

  http: HttpClient;
  mobile: Mobile[] = [];
  constructor(httpClient: HttpClient) {
    this.http = httpClient;
    this.getProducts();
  }
  getProducts() {
    this.http.get('./assets/mobile.json').subscribe(data => { this.conversion(data) });
  }
  conversion(data: any) {
    for (let ab of data) {
      let obj = new Mobile(ab.MobileId, ab.MobileName, ab.MobilePrice);
      this.mobile.push(obj);
    }
  }
  getMobiles(): Mobile[] {
    return this.mobile
  }
  deleteMobile(mid: number) {
  let foundIndex:number=-1;

  for(let i=0;i<this.mobile.length;i++)
  {
  let e=this.mobile[i]//1001,iphone 76661
     if(e.MobileId==mid)
     {
      foundIndex=i
      break;
     }

  }
  this.mobile.splice(foundIndex,1);
  }
  addMobile(mobileObj:Mobile)
  {
    this.mobile.push(mobileObj)
  }
  updateMobile(mobileObj:Mobile)
  {
    console.log("in service"+mobileObj)
    let foundIndex:number=-1;
    for(let i=0;i<this.mobile.length;i++)
    {
    let e=this.mobile[i]//1001,iphone 76661
       if(e.MobileId==mobileObj.MobileId)
       {
        foundIndex=i
        break;
       }
     }
     this.mobile[foundIndex]=mobileObj;
    }
}

export class Mobile {
  MobileId: number;
  MobileName: string;
  MobilePrice: number;

  constructor(MobileId: number, MobileName: string, MobilePrice: number) {
    this.MobileId = MobileId;
    this.MobileName = MobileName;
    this.MobilePrice = MobilePrice;
  }

}