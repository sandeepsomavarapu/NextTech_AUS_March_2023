import { Component } from '@angular/core';
import { Mobile, ProductService } from '../product.service';

@Component({
  selector: 'app-listproduct',
  templateUrl: './listproduct.component.html',
  styleUrls: ['./listproduct.component.css']
})
export class ListproductComponent {
  mobiles:Mobile[];
  constructor(private service: ProductService) {
    this.listProducts();
  }
  listProducts() {
   this.mobiles=this.service.getMobiles();
   console.log(this.mobiles);
  }


}
