import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
@Injectable({
  providedIn: 'root'
})
export class ProductService {

  http: HttpClient;
  mobile: Mobile[] = [];
  constructor(httpClient: HttpClient) {
    this.http = httpClient;
    this.getProducts();
  }
  getProducts() {
    this.http.get('./assets/mobile.json').subscribe(data => { this.conversion(data) });
  }
  conversion(data: any) {
    for (let ab of data) {
      let obj = new Mobile(ab.MobileId, ab.MobileName, ab.MobilePrice);
      this.mobile.push(obj);
    }
  }
  getMobiles(): Mobile[] {
    return this.mobile
  }

}
export class Mobile {


  MobileId: number;
  MobileName: string;
  MobilePrice: number;

  constructor(MobileId: number, MobileName: string, MobilePrice: number) {
    this.MobileId = MobileId;
    this.MobileName = MobileName;
    this.MobilePrice = MobilePrice;
  }

}