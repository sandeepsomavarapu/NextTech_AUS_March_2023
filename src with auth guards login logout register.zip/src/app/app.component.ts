import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { ProductService } from './product.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'ProductCrdOperationsUsingHttpClient';
  constructor(private router:Router,public service:ProductService)
  {

  }
  logout() {
    localStorage.removeItem("username");
    localStorage.removeItem("password");

    alert("Logout success");
    this.router.navigate(['login']);
  }

}
