import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { Mobile, ProductService } from '../product.service';

@Component({
  selector: 'app-listproduct',
  templateUrl: './listproduct.component.html',
  styleUrls: ['./listproduct.component.css']
})
export class ListproductComponent {
  line:string="MobileId";
  order:boolean=true;
  mobiles:Mobile[];
  constructor(private service: ProductService,private router:Router) {
    this.listProducts();
  }
  listProducts() {
   this.mobiles=this.service.getMobiles();
   console.log(this.mobiles);
  }
delete(mid:number)
{
  this.service.deleteMobile(mid);
  this.mobiles=this.service.getMobiles();
}
update(mid:number)
{
  this.router.navigate(['/update',mid]);
}
sort(line:string,order:boolean)
{
  this.line=line;
  if(this.line==line && order==this.order)
  {
    this.order=!order;
  }
  else
  {
    this.order=true;
  }
}
}
