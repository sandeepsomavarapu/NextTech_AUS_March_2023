import { Component } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Mobile, ProductService } from '../product.service';

@Component({
  selector: 'app-updateproduct',
  templateUrl: './updateproduct.component.html',
  styleUrls: ['./updateproduct.component.css']
})
export class UpdateproductComponent {
  MobileId:number;
  constructor(private service: ProductService,private router:Router,private route:ActivatedRoute) {
    this.MobileId=Number(this.route.snapshot.paramMap.get('mid'));
    console.log(this.MobileId)
  }
  update(mobile:Mobile)
  {
    console.log(mobile)
    this.service.updateMobile(mobile);
    alert("Mobile Updated successfully");
    this.router.navigate(['list']);
  }
}
