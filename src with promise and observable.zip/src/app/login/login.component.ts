import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent {
  uname:string;
  pass:string;
constructor(private router:Router)
{

}

login(userDetails)
{
    this.uname=localStorage.getItem("username");
    this.pass=localStorage.getItem("password");
    if(this.uname==userDetails.username && this.pass==userDetails.password)
    {
      alert("lgoin success");
    }
    else{
      alert("login failed")
    }
}

}
