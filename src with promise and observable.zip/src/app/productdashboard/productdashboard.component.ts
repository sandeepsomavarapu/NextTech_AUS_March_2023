import { Component } from '@angular/core';
import { filter, Observable, Subscriber, Subscription } from 'rxjs';

@Component({
  selector: 'app-productdashboard',
  templateUrl: './productdashboard.component.html',
  styleUrls: ['./productdashboard.component.css']
})
export class ProductdashboardComponent {
  mySubscription: Subscription;
  constructor() {
    //Promise
    // const promise = new Promise(resolve => {
    //   console.log("Promise Started");
    //   let counter = 0;
    //   setTimeout(() => {
    //     counter = counter + 1;
    //     resolve(counter);
    //   }, 1000);
    // });
    // promise.then(result => console.log(result))
    //Observable
    const observable = new Observable(sub => {
      console.log("Observable started")
      let counter = 0;
      setInterval(() => {
        counter = counter + 1;
        sub.next(counter);
      }, 1000)
    });
    //observable.pipe(filter(d=>d==="Observable is working2")).subscribe(result=>console.log(result))
    this.mySubscription=observable.subscribe(result => console.log("Subscriber count" + result))
    
  }
ngOnDestroy()
{
this.mySubscription.unsubscribe();
}
}
